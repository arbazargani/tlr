<div class="uk-overlay uk-light uk-position-bottom">
    <a class="half-opacity" href="#donate" uk-icon="icon: credit-card"></a>
</div>
<?php /**PATH /opt/lampp/htdocs/TinyLink/resources/views/public/template-parts/footer.blade.php ENDPATH**/ ?>