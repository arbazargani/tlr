<?php $__env->startSection('meta'); ?>
    <title>Tiny</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="uk-section uk-section-secondary uk-flex uk-flex-middle uk-animation-fade body" uk-height-viewport>
    <div class="uk-width-1-1">
        <div class="uk-container">
            <?php echo $__env->make('public.template-parts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="uk-grid-margin uk-grid uk-grid-stack" uk-grid>
                <div class="uk-width-1-1@m">
                    <div class="uk-margin uk-width-large uk-margin-auto uk-card uk-card- uk-card-body">

                        <form class="uk-search uk-search-default uk-width-1-1" action="<?php echo e(route('Link > Submit')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="uk-margin">
                                <div class="uk-inline uk-width-1-1">
                                    <span class="uk-form-icon" uk-icon="icon: link"></span>
                                    <input class="uk-input uk-form-large rounded" type="text" name="url"
                                           placeholder="drop your link here ..." autofocus>
                                    <?php if(session('status') == 0): ?>
                                        <span class="uk-text-meta" style="color: white"><?php echo e(session('message')); ?></span>
                                        <?php
                                            session()->forget(['status', 'message']);
                                        ?>
                                    <?php endif; ?>
                                </div>
                                <div class="uk-inline uk-width-1-1 uk-margin-top">
                                    <button type="submit"
                                            class="uk-input uk-button uk-button-primary uk-button-small uk-align-center rounded" style="width: auto">
                                        Tiny
                                    </button>
                                </div>
                            </div>
                        </form>
                        <?php if($errors->any()): ?>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <script>
                                    UIkit.notification({
                                        message: "<?php echo e($error); ?>",
                                        status: 'danger',
                                        pos: 'top-center',
                                        timeout: 5000
                                    });
                                </script>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if(session()->has('status')): ?>
                            <?php if(session('status') == 1): ?>
                                <div id="tiny-modal" uk-modal>
                                    <div class="uk-modal-dialog uk-margin-auto-vertical">
                                        <button class="uk-modal-close-default" type="button" uk-close></button>



                                        <div class="uk-modal-body uk-text-center">
                                            <span style="font-size: 2.625rem;"><?php echo e(session('tiny')); ?></span>
                                        </div>
                                        <div class="uk-modal-footer uk-text-center">
                                            <a href="<?php echo e(route('Link > Redirect', ['tiny'=> session('tiny')])); ?>" class="copy uk-button uk-button-warning" target="_blank">Open</a>
                                            <button class="copy uk-button uk-button-secondary" data-clipboard-demo="" data-clipboard-action="copy" data-clipboard-text="<?php echo e(route('Link > Redirect', session('tiny'))); ?>" onclick="UIkit.modal('#tiny-modal').hide()">Copy</button>
                                        </div>
                                    </div>
                                </div>
                                <script>
                                    var clipboard = new ClipboardJS('.copy');
                                    UIkit.modal('#tiny-modal', {
                                        'esc-close' : true,
                                        'bg-close' : true,
                                    }).show();
                                </script>
                                <?php
                                    session()->forget(['status', 'tiny']);
                                ?>
                            <?php endif; ?>
                            <?php if(session('status') == -1): ?>
                                <div id="error-modal" uk-modal>
                                    <div class="uk-modal-dialog uk-margin-auto-vertical">




                                        <div class="uk-modal-body uk-text-center">
                                            <span style="font-size: 2.625rem;"><?php echo e(session('message')); ?></span>
                                        </div>
                                        <div class="uk-modal-footer uk-text-center">
                                            <button class="uk-button uk-button-secondary" onclick="UIkit.modal('#error-modal').hide();">Close</button>
                                        </div>
                                    </div>
                                </div>
                                <script>
                                    UIkit.modal('#error-modal', {
                                        'esc-close' : true,
                                        'bg-close' : true,
                                    }).show();
                                </script>
                                <?php
                                    session()->forget(['status', 'message']);
                                ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/TinyLink/resources/views/public/home/index.blade.php ENDPATH**/ ?>