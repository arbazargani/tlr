<?php $__env->startSection('content'); ?>
    <div class="container uk-padding">
        <div class="uk-card uk-card-default uk-card-hover uk-card-body">
            <h1 class="uk-card-title">لینک‌های ثبت شده</h1>
            <hr>
            <div class="uk-overflow-auto">
            <?php if(count($links->links) > 0): ?>
                <table class="uk-table uk-table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>لینک اصلی</th>
                        <th>لینک کوتاه</th>
                        <th>تاریخ ثبت</th>
                        <th>تاریخ انقضا</th>
                        <th>بازدید</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $links->links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($link->url); ?></td>
                            <td><a href="<?php echo e(route('Link > Redirect', $link->tiny)); ?>"><?php echo e($link->tiny); ?></a></td>
                            <td><?php echo e($link->created_at); ?></td>
                            <td>
                                <?php if($link->deactivate < date('Y-m-d H-i-s')): ?>
                                    <span class="uk-text-danger">منقضی شده</span>
                                <?php else: ?>
                                    <?php echo e($link->deactivate); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($link->views); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
                <div>
                    <?php echo e($links->links->render("pagination::uikit")); ?>

                </div>
            <?php else: ?>
                <div class="uk-alert uk-alert-warning">
                    شما تا بحال لینکی ثبت نکرده‌اید.
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('panel.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/TinyLink/resources/views/panel/links/index.blade.php ENDPATH**/ ?>