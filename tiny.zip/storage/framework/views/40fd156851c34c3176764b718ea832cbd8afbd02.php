<?php $__env->startSection('meta'); ?>
    <title>Tiny Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-padder content-background uk-background-secondary">

    <div class="uk-section-small">
        <div class="uk-container uk-container-large">
            <div uk-grid class="uk-child-width-1-1@s uk-child-width-1-2@m uk-child-width-1-4@xl">
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <span class="statistics-text"><span uk-icon="icon: link"></span> Today Links</span><br />
                        <span class="statistics-number">
                            <?php echo e(count($todayLinks)); ?>

                            <?php if(count($todayLinks) > count($yesterdayLinks)): ?>
                            <span class="uk-label uk-label-success">
                                <?php echo e(count($todayLinks) - count($yesterdayLinks)); ?> <span class="ion-arrow-up-c"></span>
                            </span>
                            <?php elseif(count($todayLinks) < count($yesterdayLinks)): ?>
                            <span class="uk-label uk-label-danger">
                                <?php echo e(count($todayLinks) - count($yesterdayLinks)); ?> <span class="ion-arrow-down-c"></span>
                            </span>
                            <?php else: ?>
                            <span class="uk-label" style="background-color: gray;">
                                <?php echo e(count($todayLinks) - count($yesterdayLinks)); ?> -
                            </span>
                            <?php endif; ?>
                        </span>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <span class="statistics-text"><span uk-icon="icon: user"></span> Today Traffic</span><br />
                        <span class="statistics-number">
                            123.238
                            <span class="uk-label uk-label-danger">
                                13% <span class="ion-arrow-down-c"></span>
                            </span>
                        </span>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <span class="statistics-text"><span uk-icon="icon: plus"></span> Total Links</span><br />
                        <span class="statistics-number">
                            <?php echo e($totalLinks); ?>

                            <span class="uk-label uk-label-success">
                                37% <span class="ion-arrow-up-c"></span>
                            </span>
                        </span>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default uk-card-body">
                        <span class="statistics-text"><span uk-icon="icon: credit-card"></span> Total Income</span><br />
                        <span class="statistics-number">
                            6.384€
                            <span class="uk-label uk-label-success">
                                26% <span class="ion-arrow-up-c"></span>
                            </span>
                        </span>
                    </div>
                </div>
            </div>
            <div uk-grid class="uk-child-width-1-1@s uk-child-width-1-2@m uk-child-width-1-4@xl">
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-header">
                            Website Traffic
                        </div>
                        <div class="uk-card-body">
                            <canvas id="chart1"></canvas>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-header">
                            Website Traffic
                        </div>
                        <div class="uk-card-body">
                            <canvas id="chart2"></canvas>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-header">
                            Links Registered
                        </div>
                        <div class="uk-card-body">
                            <div style="height: 200px;">
                                <?php echo $Link_Count_Chart->container(); ?>

                                <?php echo $Link_Count_Chart->script(); ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="uk-card uk-card-default">
                        <div class="uk-card-header">
                        Loyal Users
                        </div>
                        <div class="uk-card-body">
                            <div style="height: 200px;">
                            <?php echo $loyal_users_chart->container(); ?>

                            <?php echo $loyal_users_chart->script(); ?>

                            </div>
                        </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/TinyLink/resources/views/admin/home/index.blade.php ENDPATH**/ ?>