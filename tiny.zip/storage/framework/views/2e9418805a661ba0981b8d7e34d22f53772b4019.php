<?php $__env->startSection('meta'); ?>
    <title>Tiny Admin</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="content-padder content-background">
    <br>
    <div class="uk-container uk-background-default uk-padding-large" style="margin: 10px !important;">
        <div class="uk-container uk-margin-small" uk-margin>
            <form method="get">
            <!-- <?php echo csrf_field(); ?> -->
            <div class="uk-margin" uk-margin>
                <fieldset class="uk-fieldset">
                    <?php if(isset($error)): ?>
                        <span class="uk-text-meta uk-text-danger">Try changing search type.</span>
                    <?php endif; ?>
                    <div class="uk-margin uk-grid-small uk-child-width-auto uk-grid">
                        <label><input class="uk-radio" type="radio" name="find_by" value="id" checked> ID</label>
                        <label><input class="uk-radio" type="radio" name="find_by" value="tiny"> Tiny</label>
                    </div>
                    <div class="uk-margin">
                        <input type="text" class="uk-input " name="link" placeholder="Place id or tiny.">
                    </div>
                    <div class="uk-margin">
                        <button class="uk-button uk-button-primary">Find</button>
                    </div>
                </fieldset>
            </div>
            </form>

            <?php if(isset($_GET['link'])): ?>
                <?php if(isset($link) && !is_null($link)): ?>
                    
                    <table class="uk-table uk-table-hover uk-table-divider">
                    <style>
                        thead > tr > th {
                            text-align: left !important;
                        }
                    </style>
                    <thead>
                    <tr>
                        <th>URL</th>
                        <th>TLD</th>
                        <th>TINY</th>
                        <th>VIEWS</th>
                        <th>STATE</th>
                        <th>IP</th>
                        <th>Registered_AT</th>
                        <th>DEACTIVATE</th>
                        <th>DELETE</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td><?php echo e($link->url); ?></td>
                        <td><?php echo e($link->tld); ?></td>
                        <td><a href="<?php echo e(route('Link > Redirect', $link->tiny)); ?>"><?php echo e($link->tiny); ?></a></td>
                        <td><?php echo e($link->views); ?></td>
                        <td><?php echo e($link->state); ?></td>
                        <td><?php echo e($link->ip); ?></td>
                        <td><?php echo e($link->registered_at); ?></td>
                        <td>
                            <?php if($link->state): ?>
                                <button type="submit" class="uk-button uk-button-secondary uk-button-small" uk-toggle="target: #deactivate_<?php echo e($link->id); ?>">Deactivate</button>
                                <div id="deactivate_<?php echo e($link->id); ?>" uk-modal>
                                    <div class="uk-modal-dialog uk-modal-body">
                                        <h2 class="uk-modal-title">Operation confirmation</h2>
                                        <p>
                                            You're going to <span class="uk-text-danger">deactivate</span> this link. are you sure?
                                        </p>
                                        <form action="<?php echo e(route('Admin > Links > Deactivate', $link->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <p class="uk-text-right">
                                                <input type="hidden" name="id" value="<?php echo e($link->id); ?>">
                                                <button class="uk-button uk-button-default uk-modal-close">cancel</button>
                                                <button class="uk-button uk-button-primary" type="submit">yes</button>
                                            </p>
                                        </form>
                                    </div>
                                </div>
                            <?php else: ?>
                                <button type="submit" class="uk-button uk-button-default uk-button-small" uk-toggle="target: #activate_<?php echo e($link->id); ?>">Activate</button>
                                <div id="activate_<?php echo e($link->id); ?>" uk-modal>
                                    <div class="uk-modal-dialog uk-modal-body">
                                        <h2 class="uk-modal-title">Operation confirmation</h2>
                                        <p>
                                            You're going to <span class="uk-text-primary">activate</span> this link. are you sure?
                                        </p>
                                        <form action="<?php echo e(route('Admin > Links > Activate', $link->id)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <p class="uk-text-right">
                                                <input type="hidden" name="id" value="<?php echo e($link->id); ?>">
                                                <button class="uk-button uk-button-default uk-modal-close">cancel</button>
                                                <button class="uk-button uk-button-primary" type="submit">yes</button>
                                            </p>
                                        </form>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <button type="submit" class="uk-button uk-button-danger uk-button-small" uk-toggle="target: #delete_<?php echo e($link->id); ?>">Delete</button>
                            <div id="delete_<?php echo e($link->id); ?>" uk-modal>
                                <div class="uk-modal-dialog uk-modal-body">
                                    <h2 class="uk-modal-title">Operation confirmation</h2>
                                    <p>
                                        You're going to <span class="uk-text-danger">delete</span> this link. are you sure? <br>
                                    <div class="uk-alert uk-alert-danger">
                                        action is not restorable.
                                    </div>
                                    </p>
                                    <form action="<?php echo e(route('Admin > Links > Delete', $link->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <p class="uk-text-right">
                                            <input type="hidden" name="id" value="<?php echo e($link->id); ?>">
                                            <button class="uk-button uk-button-default uk-modal-close">cancel</button>
                                            <button class="uk-button uk-button-primary" type="submit">yes</button>
                                        </p>
                                    </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                    </tbody>
                    </table>
                    
                <?php else: ?>
                    <div class="uk-alert uk-alert-warning">
                        <p>
                            Unregistered link. <br>
                        </p>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/TinyLink/resources/views/admin/link/find.blade.php ENDPATH**/ ?>