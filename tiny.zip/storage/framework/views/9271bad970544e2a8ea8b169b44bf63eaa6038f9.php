





<?php /**PATH /opt/lampp/htdocs/TinyLink/resources/views/panel/template-parts/footer.blade.php ENDPATH**/ ?>