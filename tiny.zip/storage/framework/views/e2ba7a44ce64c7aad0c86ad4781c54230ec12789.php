<nav class="uk-navbar-nav uk-background-muted uk-padding-large uk-padding-remove-top uk-padding-remove-bottom" uk-navbar>
    <div class="uk-navbar-right">
        <ul class="uk-navbar-nav">
            <li class="uk-active"><a href="<?php echo e(route('Panel')); ?>">صفحه اصلی</a></li>
            <li ><a href="<?php echo e(route('Panel > Links')); ?>">لینک‌ها</a></li>
        </ul>
    </div>
    <div class="uk-navbar-left">
        <li>
            <form action="<?php echo e(route('logout')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <button type="submit" class="uk-button uk-button-link uk-text-danger">خروج</button>
            </form>
        </li>
    </div>
</nav>
<?php /**PATH /opt/lampp/htdocs/TinyLink/resources/views/panel/template-parts/navigation.blade.php ENDPATH**/ ?>