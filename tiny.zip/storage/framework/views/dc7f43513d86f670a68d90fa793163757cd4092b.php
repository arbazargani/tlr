<meta charset="UTF-8">
<meta name="description" content="Clean and responsive administration panel">
<meta name="keywords" content="Admin,Panel,HTML,CSS,XML,JavaScript">
<meta name="author" content="Erik Campobadal">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- UIkit CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/uikit-rtl.min.css')); ?>" />

<!-- Custom CSS -->
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/notyf.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('assets/admin/css/style.css')); ?>" />

<!-- UIkit js -->
<script src="<?php echo e(asset('assets/admin/js/uikit.min.js')); ?>" ></script>


<!-- Jquery -->



<!-- Chart Js -->




<?php /**PATH /opt/lampp/htdocs/TinyLink/resources/views/panel/template-parts/header.blade.php ENDPATH**/ ?>