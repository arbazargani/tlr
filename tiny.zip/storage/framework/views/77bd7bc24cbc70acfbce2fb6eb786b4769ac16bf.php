<?php $__env->startSection('meta'); ?>
    <title>یافت نشد ...</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="uk-section uk-section-secondary uk-flex uk-flex-middle uk-animation-fade body" uk-height-viewport>
        <div class="uk-width-1-1">
            <div class="uk-container">
                <?php echo $__env->make('public.template-parts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="uk-container uk-text-center">
                    <h1 style="font-family: IranSans; font-size: 100px;">۴۰۴</h1>
                    <p style="font-family: IranSans; direction: rtl;">صفحه موردنظر وجود ندارد!</p>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/TinyLink/resources/views/errors/404.blade.php ENDPATH**/ ?>