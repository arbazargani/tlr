<!-- Load More Javascript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.0/Chart.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.transit/0.9.12/jquery.transit.min.js"></script>
<script src="<?php echo e(asset('assets/admin/js/notyf.min.js')); ?>"></script>
<!-- Required Overall Script -->
<script src="<?php echo e(asset('assets/admin/js/script.js')); ?>"></script>
    <!-- Status Updater -->
<script src="<?php echo e(asset('assets/admin/js/status.js')); ?>"></script>
<!-- Sample Charts -->
<script src="<?php echo e(asset('assets/admin/js/charts.js')); ?>"></script>
<!-- Sample Notifications -->
<script src="<?php echo e(asset('assets/admin/js/notification.js')); ?>"></script>
<?php /**PATH /opt/lampp/htdocs/TinyLink/resources/views/admin/template-parts/footer.blade.php ENDPATH**/ ?>