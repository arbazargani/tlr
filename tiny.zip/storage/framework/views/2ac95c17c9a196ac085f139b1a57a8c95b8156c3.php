<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="rtl">
<head>
    <?php echo $__env->yieldContent('meta'); ?>
    <meta name="robots" content="noindex, nofollow">
    <?php echo $__env->make('panel.template-parts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <style>
        *:not(i) {
            font-family: IRANSans !important;
        }
    </style>
</head>
<body>
<?php echo $__env->make('panel.template-parts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('panel.template-parts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/TinyLink/resources/views/panel/template.blade.php ENDPATH**/ ?>