<div class="uk-section-small uk-section-default header">
    <div class="uk-container uk-container-large">
        <h1><span class="ion-speedometer"></span> Dashboard</h1>
        <p>
            Welcome back, {{ Auth::User()->name }}
        </p>
        <ul class="uk-breadcrumb">
            <li><a href="index.html">Home</a></li>
            <li><span href="">Dashboard</span></li>
        </ul>
    </div>
</div>
