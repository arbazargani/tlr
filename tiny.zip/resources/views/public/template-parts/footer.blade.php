<div class="uk-overlay uk-light uk-position-bottom">
    <a class="half-opacity" href="#donate" uk-icon="icon: credit-card"></a>
</div>
